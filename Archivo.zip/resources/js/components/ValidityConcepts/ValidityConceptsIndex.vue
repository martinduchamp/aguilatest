<template>
    <div>
        <div class="md:flex md:items-center md:justify-between my-5 ">
            <div class="min-w-0 flex-1">
                <h2 class="text-2xl font-bold leading-7 text-gray-900 dark:text-gray-200 sm:truncate sm:text-3xl sm:tracking-tight">Conceptos de vigencia para tractor</h2>
            </div>
        </div>
        <div class="border-b border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 px-4 py-5 sm:px-6  shadow dark:shadow-2xl sm:rounded">
            <div class="-ml-4 -mt-2 flex flex-wrap items-center justify-between sm:flex-nowrap">
                <div class="ml-4 mt-2">
                    <!-- <h3 class="text-base font-semibold leading-6 text-gray-900">Job Postings</h3> -->
                </div>
                <div class="ml-4 mt-2 flex-shrink-0">
                    <router-link :to="{ name: 'validity_concepts.create' }"
                        class="relative inline-flex items-center rounded-md bg-indigo-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600">Crear
                        nuevo</router-link>
                </div>
            </div>

            <div class="mt-8 flow-root uppercase dark:bg-gray-900">
                <div class="-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                    <div class="inline-block min-w-full py-2 align-middle sm:px-6 lg:px-8">

                        <TransitionGroup name="list" tag="table" class="min-w-full divide-y divide-gray-300 dark:dive-gray-700">
                            <thead>
                                <tr class="dark:text-white">
                                    <th scope="col" class="py-3.5 pl-4 pr-3 text-left font-semibold text-gray-900 dark:text-white sm:pl-0">
                                        NOMBRE
                                    </th>
                                    <th scope="col" class="px-3 py-3.5 text-left  font-semibold text-gray-900 dark:text-white">RFC
                                    </th>
                                    <th scope="col" class="px-3 py-3.5 text-left  font-semibold text-gray-900 dark:text-white">CP
                                    </th>
                                    <th scope="col" class="px-3 py-3.5 text-left  font-semibold text-gray-900 dark:text-white">CIUDAD
                                    </th>
                                    <th scope="col" class="relative py-3.5 pl-3 pr-4 sm:pr-0">
                                        <span class="sr-only">Editar</span>
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-200 dark:divide-gray-700">

                                <tr v-for="validity_concept in validity_concepts"
                                    :key="validity_concept.id" class="transition-all">
                                    <td class="whitespace-nowrap py-4 pl-4 pr-3 text-sm  font-medium text-gray-900 sm:pl-0">
                                        {{ validity_concept.name }}</td>
                                    
                                    <td
                                        class="relative whitespace-nowrap py-4 pl-3 pr-4 text-right text-sm font-medium sm:pr-0">
                                        <router-link :to="{ name: 'validity_concepts.edit', params: { id: validity_concept.id } }" href="#" class="text-indigo-600 hover:text-indigo-900 mx-5">Editar<span
                                                class="sr-only">, {{ validity_concept.id }}</span></router-link>
                                        <a href="#" @click="deleteValidityConcept(validity_concept.id)"
                                            class="font-medium text-red-600 dark:text-red-500 hover:underline">ELIMINAR</a>
                                    </td>
                                </tr>

                            </tbody>
                        </TransitionGroup>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
  
<script setup>
import useValidityConcepts from '../../composables/validityConcept.js';
import { onMounted } from 'vue';
const { validity_concepts, getValidityConcepts, destroyValidityConcepts } = useValidityConcepts();

onMounted(getValidityConcepts());

const deleteValidityConcept = async (id) => {
    if (!window.confirm('Estas seguro?')) {
        return;
    }
    await destroyValidityConcepts(id);
    await getValidityConcepts();
}
</script>
<style>
.list-enter-active,
.list-leave-active {
    transition: all 0.5s ease;
}

.list-enter-from,
.list-leave-to {
    opacity: 0;
    transform: translateX(30px);
}
</style>